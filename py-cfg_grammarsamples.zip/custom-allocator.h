// custom-allocator.h
//
// Mark Johnson, 23rd April 2005, modified 27th August 2009

#pragma once
